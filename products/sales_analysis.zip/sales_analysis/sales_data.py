# sales_data.py
sales_data = [230, 200, 310, 290, 400, 150, 180]
print(f"Sales data for the week: {sales_data}")

def total_sales(data):
    total=sum(data)
    return total

def average_sales(data):
    if len(data)==0:
        return 0
    else:
        average=sum(data)/len(data)
        return average
    
total=total_sales(sales_data)
average=average_sales(sales_data)
print(f"Ukupna vrijednost: {total}")
print(f"Prosjek: {average}")

# Weekly sales data: [Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday]
sales_data = [230, 200, 310, 290, 400, 150, 180]